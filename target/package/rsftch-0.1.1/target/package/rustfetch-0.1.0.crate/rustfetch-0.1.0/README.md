# Rustfetch

##### _Lightning fast hardware fetch written in rust._

### Screenshots

### Supported distros
- Arch Linux
- Debian
- Fedora
- Endeavour OS

### Installation
- `git clone https://github.com/charklie/rustfetch.git ~/rustfetch/`
- `cd rustfetch`
- `cargo install --release`
- `export PATH=$PATH:~/.cargo/bin/`

### Usage
- `rustfetch`

