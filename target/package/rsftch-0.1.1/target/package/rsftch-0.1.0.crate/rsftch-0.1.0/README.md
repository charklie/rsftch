# RsFtch

##### _Lightning fast hardware fetch written in rust._

### Screenshots

### Supported distros
- Arch Linux
- Debian
- Fedora
- Endeavour OS

* Other distros wont have a custom title, only "Rust Fetch"

### Installation
- `git clone https://github.com/charklie/rsftch.git ~/rsftch/`
- `cd rsftch`
- `cargo install --path .`

### Usage
- `rsftch`

